# AWS credentials
AWS_ACCESS_KEY=AKIAJFMT47OTFFAJYEJQ
AWS_SECRET_KEY=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
AWS_DEFAULT_REGION=us-east-2
S3_BUCKET_NAME=exgblrecordings

RECORDINGS_DIR=$1

echo "Uploading the recording to S3"

# Get the folder name
RECORDINGS=`ls $RECORDINGS_DIR/*.mp4`
RECORDINGS=`basename $RECORDINGS`
FOLDER_NAME=$(echo $RECORDINGS | tr "_" "\n")

for name in $FOLDER_NAME
do
	FOLDER_NAME=$name
	break
done


conc(){
	echo "Concatenating..."

	FILE_NAME=$(basename $(ls $RECORDINGS_DIR/*.mp4))

	cat /home/recordings/concatenate > /tmp/concatenate

	cp /home/recordings/intro.mp4 /tmp/intro.mp4

	cp $RECORDINGS_DIR/*.mp4 /tmp

	OUTPUT=$(tempfile)

	sed -i s/video/"$FILE_NAME"/g /tmp/concatenate

	ffmpeg -f  concat -safe 0 -i /tmp/concatenate  $OUTPUT.mp4 && rm $RECORDINGS_DIR/*.mp4 && cp -vf $OUTPUT.mp4 $RECORDINGS_DIR/$FILE_NAME

	#	cd /tmp && mencoder -oac copy -ovc copy intro.mp4  $FILE_NAME -o $OUTPUT.mp4 && rm $RECORDINGS_DIR/*.mp4 && cp -vf $OUTPUT.mp4 $RECORDINGS_DIR/$FILE_NAME  && cd ..

#	cd /tmp && mencoder -oac copy -ovc copy intro.mp4  $FILE_NAME -o $OUTPUT.mp4 && rm $RECORDINGS_DIR/*.mp4 && cp -vf $OUTPUT.mp4 $RECORDINGS_DIR/$FILE_NAME  && cd ..

#MP4Box -add /tmp/intro.mp4 -cat /tmp/$FILE_NAME $OUTPUT.mp4 && cp -vf $OUTPUT.mp4 $RECORDINGS_DIR/$FILE_NAME
}



sendsessionid(){



	SESSIONID="$(echo "$FILE_NAME" | awk -F '_' '{print $1}')"
	UPLOADED_AT="$(echo "$FILE_NAME" |awk -F'_' '{print $2}' |awk -F'.' '{print $1}')"


	curl --location --request POST 'https://api.expertlyglobal.com/meetings/add-recording-to-session' \
		--header 'Content-Type: application/x-www-form-urlencoded' \
		--header 'Content-Type: application/x-www-form-urlencoded' \
		--data-urlencode "session_id=$SESSIONID" \
		--data-urlencode "uploaded_at=$UPLOADED_AT" \
		--data-urlencode "filename=$FILE_NAME"




echo "$SESSIONID\n$UPLOADED_AT\n$FILE_NAME" >> /tmp/log.txt


	}



upload(){

	echo "Uploading..."
	# Set credentials for aws cli
	aws configure set aws_access_key_id $AWS_ACCESS_KEY
	aws configure set aws_secret_access_key $AWS_SECRET_KEY
	aws configure set default.region $AWS_DEFAULT_REGION

	# Upload to S3
	aws s3 sync $RECORDINGS_DIR s3://$S3_BUCKET_NAME/recordings/$FOLDER_NAME/

	# Get the instance ID and terminate the EC2 instance
	die() { status=$1; shift; echo "FATAL: $*"; exit $status; }
	INSTANCE_ID="`wget -q -O - http://169.254.169.254/latest/meta-data/instance-id || die \"wget instance-id has failed: $?\"`"

	aws ec2 terminate-instances --instance-ids $INSTANCE_ID

}


conc
upload
sendsessionid
